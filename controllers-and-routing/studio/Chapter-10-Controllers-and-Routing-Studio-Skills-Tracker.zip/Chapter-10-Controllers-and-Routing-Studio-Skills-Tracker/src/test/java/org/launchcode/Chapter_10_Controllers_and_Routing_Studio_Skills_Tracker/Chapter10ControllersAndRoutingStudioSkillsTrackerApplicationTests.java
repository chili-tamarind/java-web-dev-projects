package org.launchcode.Chapter_10_Controllers_and_Routing_Studio_Skills_Tracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chapter10ControllersAndRoutingStudioSkillsTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
