package org.launchcode.Chapter_10_Controllers_and_Routing_Studio_Skills_Tracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter10ControllersAndRoutingStudioSkillsTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(Chapter10ControllersAndRoutingStudioSkillsTrackerApplication.class, args);
	}

}
